/**
 * Catálogo G — inventario Global (empresa, producto, bodega, foto, estado).
 */
const fs = require('fs');
const path = require('path');
const config = require('../config');

const ESTADOS = ['Nuevo', 'Usado', 'Chatarra', 'Venta a Tercero'];
const UPLOAD_DIR = path.join(config.publicDir, 'uploads', 'catalogo-g');
const TABLE = 'catalogo_g';

async function ensureCatalogoGSchema(db) {
  if (db.driver === 'mysql') {
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLE} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        codigo VARCHAR(64) NULL,
        empresa VARCHAR(255) NOT NULL,
        descripcion TEXT NOT NULL,
        cantidad DECIMAL(15,2) NOT NULL DEFAULT 0,
        bodega VARCHAR(255) NULL,
        foto VARCHAR(512) NULL,
        estado VARCHAR(64) NOT NULL DEFAULT 'Nuevo',
        creado_por INT NULL,
        actualizado_por INT NULL,
        eliminado TINYINT NOT NULL DEFAULT 0,
        fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
        fecha_actualizacion DATETIME NULL
      )
    `);
  } else {
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLE} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo TEXT,
        empresa TEXT NOT NULL,
        descripcion TEXT NOT NULL,
        cantidad REAL NOT NULL DEFAULT 0,
        bodega TEXT,
        foto TEXT,
        estado TEXT NOT NULL DEFAULT 'Nuevo',
        creado_por INTEGER,
        actualizado_por INTEGER,
        eliminado INTEGER NOT NULL DEFAULT 0,
        fecha_creacion TEXT DEFAULT (datetime('now')),
        fecha_actualizacion TEXT
      )
    `);
  }
}

function normalizeEstado(v) {
  const s = String(v || '').trim();
  return ESTADOS.includes(s) ? s : 'Nuevo';
}

async function nextCodigo(db) {
  const row = await db.prepare(
    `SELECT codigo AS c FROM ${TABLE} WHERE codigo LIKE ? ORDER BY id DESC LIMIT 1`
  ).get('CATG-%');
  let n = 1;
  if (row?.c) {
    const m = String(row.c).match(/(\d+)\s*$/);
    if (m) n = Number(m[1]) + 1;
  }
  return `CATG-${String(n).padStart(5, '0')}`;
}

async function listCatalogoG(db) {
  await ensureCatalogoGSchema(db);
  const nameExpr = (alias) => (db.driver === 'mysql'
    ? `TRIM(CONCAT(COALESCE(${alias}.nombre,''), ' ', COALESCE(${alias}.apellido,'')))`
    : `TRIM(COALESCE(${alias}.nombre,'') || ' ' || COALESCE(${alias}.apellido,''))`);
  return db.prepare(`
    SELECT c.*,
           ${nameExpr('u')} AS creador,
           ${nameExpr('a')} AS editor
    FROM ${TABLE} c
    LEFT JOIN usuarios u ON u.id = c.creado_por
    LEFT JOIN usuarios a ON a.id = c.actualizado_por
    WHERE c.eliminado = 0
    ORDER BY c.id DESC
  `).all();
}

async function createCatalogoG(db, userId, body) {
  await ensureCatalogoGSchema(db);
  const empresa = String(body.empresa || '').trim();
  const descripcion = String(body.descripcion || '').trim();
  if (!empresa) {
    const err = new Error('Empresa requerida');
    err.status = 400;
    throw err;
  }
  if (!descripcion) {
    const err = new Error('Descripción del producto requerida');
    err.status = 400;
    throw err;
  }
  const codigo = await nextCodigo(db);
  const cantidad = Number(body.cantidad);
  const info = await db.prepare(`
    INSERT INTO ${TABLE}
      (codigo, empresa, descripcion, cantidad, bodega, foto, estado, creado_por, actualizado_por)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    codigo,
    empresa,
    descripcion,
    Number.isFinite(cantidad) ? cantidad : 0,
    String(body.bodega || '').trim() || null,
    body.foto || null,
    normalizeEstado(body.estado),
    userId || null,
    userId || null
  );
  return { id: info.lastInsertRowid, codigo };
}

async function updateCatalogoG(db, id, userId, body) {
  await ensureCatalogoGSchema(db);
  const cur = await db.prepare(`SELECT * FROM ${TABLE} WHERE id = ? AND eliminado = 0`).get(Number(id));
  if (!cur) {
    const err = new Error('Registro no encontrado');
    err.status = 404;
    throw err;
  }
  const empresa = body.empresa != null ? String(body.empresa).trim() : cur.empresa;
  const descripcion = body.descripcion != null ? String(body.descripcion).trim() : cur.descripcion;
  if (!empresa || !descripcion) {
    const err = new Error('Empresa y descripción son obligatorias');
    err.status = 400;
    throw err;
  }
  const cantidad = body.cantidad != null ? Number(body.cantidad) : Number(cur.cantidad);
  await db.prepare(`
    UPDATE ${TABLE} SET
      empresa = ?, descripcion = ?, cantidad = ?, bodega = ?,
      foto = ?, estado = ?, actualizado_por = ?,
      fecha_actualizacion = ${db.driver === 'mysql' ? 'NOW()' : "datetime('now')"}
    WHERE id = ?
  `).run(
    empresa,
    descripcion,
    Number.isFinite(cantidad) ? cantidad : 0,
    body.bodega != null ? (String(body.bodega).trim() || null) : cur.bodega,
    body.foto !== undefined ? (body.foto || null) : cur.foto,
    body.estado != null ? normalizeEstado(body.estado) : cur.estado,
    userId || null,
    Number(id)
  );
  return { id: Number(id) };
}

async function deleteCatalogoG(db, id, userId) {
  await ensureCatalogoGSchema(db);
  const info = await db.prepare(`
    UPDATE ${TABLE} SET eliminado = 1, actualizado_por = ?,
      fecha_actualizacion = ${db.driver === 'mysql' ? 'NOW()' : "datetime('now')"}
    WHERE id = ? AND eliminado = 0
  `).run(userId || null, Number(id));
  if (!info.changes) {
    const err = new Error('Registro no encontrado');
    err.status = 404;
    throw err;
  }
}

function saveCatalogoGPhoto(dataUrl) {
  if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) {
    const err = new Error('Imagen inválida');
    err.status = 400;
    throw err;
  }
  const m = dataUrl.match(/^data:image\/(png|jpe?g|webp|gif);base64,(.+)$/i);
  if (!m) {
    const err = new Error('Formato de imagen no soportado');
    err.status = 400;
    throw err;
  }
  let ext = m[1].toLowerCase();
  if (ext === 'jpeg') ext = 'jpg';
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 8 * 1024 * 1024) {
    const err = new Error('La imagen supera 8 MB');
    err.status = 400;
    throw err;
  }
  if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const name = `catg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  return `/uploads/catalogo-g/${name}`;
}

module.exports = {
  ESTADOS,
  ensureCatalogoGSchema,
  listCatalogoG,
  createCatalogoG,
  updateCatalogoG,
  deleteCatalogoG,
  saveCatalogoGPhoto
};
