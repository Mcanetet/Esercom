/**
 * Cerebro de Angel IA: documentos (texto, imagen, excel, word, pdf)
 * + recuperación por relevancia (mente ligera) para no inyectar todo el corpus.
 */
const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const config = require('../config');

const TABLE = 'angel_ia_conocimiento_docs';
const CHUNKS = 'angel_ia_conocimiento_chunks';
const DIR = path.join(config.dataDir, 'angel-conocimiento');
const MAX_TEXT = 60000;
const MAX_PROMPT_CHARS = 7000;
const MAX_CHUNKS_IN_PROMPT = 8;
const CHUNK_SIZE = 900;
const CHUNK_OVERLAP = 120;

const TYPE_META = {
  texto: { icon: 'fa-align-left', label: 'Texto' },
  excel: { icon: 'fa-file-excel', label: 'Excel' },
  word: { icon: 'fa-file-word', label: 'Word' },
  pdf: { icon: 'fa-file-pdf', label: 'PDF' },
  imagen: { icon: 'fa-image', label: 'Imagen' },
  otro: { icon: 'fa-file', label: 'Archivo' }
};

function ensureDir() {
  if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });
}

async function columnExists(db, table, col) {
  try {
    if (db.driver === 'mysql') {
      const rows = await db.prepare(`
        SELECT COLUMN_NAME AS name FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
      `).all(table, col);
      return rows.length > 0;
    }
    const rows = await db.prepare(`PRAGMA table_info(${table})`).all();
    return rows.some((r) => r.name === col);
  } catch (_) {
    return false;
  }
}

async function ensureAngelDocsSchema(db) {
  ensureDir();
  if (db.driver === 'mysql') {
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLE} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(255) NOT NULL,
        archivo VARCHAR(512) NULL,
        tipo VARCHAR(32) NOT NULL DEFAULT 'excel',
        mime VARCHAR(120) NULL,
        texto LONGTEXT NULL,
        resumen VARCHAR(500) NULL,
        filas INT NOT NULL DEFAULT 0,
        hojas INT NOT NULL DEFAULT 0,
        creado_por INT NULL,
        fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${CHUNKS} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        doc_id INT NOT NULL,
        idx_chunk INT NOT NULL DEFAULT 0,
        texto LONGTEXT NOT NULL,
        FOREIGN KEY (doc_id) REFERENCES ${TABLE}(id) ON DELETE CASCADE
      )
    `);
  } else {
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLE} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        archivo TEXT,
        tipo TEXT NOT NULL DEFAULT 'excel',
        mime TEXT,
        texto TEXT,
        resumen TEXT,
        filas INTEGER NOT NULL DEFAULT 0,
        hojas INTEGER NOT NULL DEFAULT 0,
        creado_por INTEGER,
        fecha_creacion TEXT DEFAULT (datetime('now'))
      )
    `);
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${CHUNKS} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doc_id INTEGER NOT NULL,
        idx_chunk INTEGER NOT NULL DEFAULT 0,
        texto TEXT NOT NULL
      )
    `);
  }

  const extras = [
    ['tipo', db.driver === 'mysql' ? "VARCHAR(32) NOT NULL DEFAULT 'excel'" : "TEXT NOT NULL DEFAULT 'excel'"],
    ['mime', db.driver === 'mysql' ? 'VARCHAR(120) NULL' : 'TEXT'],
    ['resumen', db.driver === 'mysql' ? 'VARCHAR(500) NULL' : 'TEXT']
  ];
  for (const [col, ddl] of extras) {
    if (!(await columnExists(db, TABLE, col))) {
      try {
        await db.exec(`ALTER TABLE ${TABLE} ADD COLUMN ${col} ${ddl}`);
      } catch (_) { /* already exists / race */ }
    }
  }
}

function decodeDataUrl(dataUrl, maxMb = 12) {
  const m = String(dataUrl || '').match(/^data:([^;]+);base64,(.+)$/i);
  if (!m) {
    const err = new Error('Archivo inválido');
    err.status = 400;
    throw err;
  }
  const mime = m[1];
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > maxMb * 1024 * 1024) {
    const err = new Error(`El archivo supera ${maxMb} MB`);
    err.status = 400;
    throw err;
  }
  return { buf, mime };
}

function safeName(filename, fallback) {
  return String(filename || fallback)
    .replace(/[^\w.\- áéíóúñÁÉÍÓÚÑ]/g, '_')
    .slice(0, 180);
}

function detectTipo(filename, mime) {
  const name = String(filename || '').toLowerCase();
  const m = String(mime || '').toLowerCase();
  if (/\.xlsx$/i.test(name) || m.includes('spreadsheet') || m.includes('excel')) return 'excel';
  if (/\.docx?$/i.test(name) || m.includes('wordprocessingml') || m.includes('msword')) return 'word';
  if (/\.pdf$/i.test(name) || m.includes('pdf')) return 'pdf';
  if (/\.(png|jpe?g|webp|gif)$/i.test(name) || m.startsWith('image/')) return 'imagen';
  if (/\.(txt|md|csv)$/i.test(name) || m.startsWith('text/')) return 'texto';
  return 'otro';
}

function truncate(text, max = MAX_TEXT) {
  const t = String(text || '').trim();
  if (t.length <= max) return t;
  return t.slice(0, max) + '\n…[truncado]';
}

function chunkText(text) {
  const clean = String(text || '').replace(/\r\n/g, '\n').trim();
  if (!clean) return [];
  const chunks = [];
  let i = 0;
  while (i < clean.length && chunks.length < 80) {
    const end = Math.min(clean.length, i + CHUNK_SIZE);
    let slice = clean.slice(i, end);
    if (end < clean.length) {
      const lastBreak = Math.max(slice.lastIndexOf('\n'), slice.lastIndexOf('. '), slice.lastIndexOf(' '));
      if (lastBreak > CHUNK_SIZE * 0.5) slice = slice.slice(0, lastBreak + 1);
    }
    const piece = slice.trim();
    if (piece) chunks.push(piece);
    if (i + slice.length >= clean.length) break;
    i += Math.max(1, slice.length - CHUNK_OVERLAP);
  }
  return chunks;
}

async function extractExcelText(buffer) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer);
  const parts = [];
  let filas = 0;
  let hojas = 0;
  wb.eachSheet((sheet) => {
    hojas += 1;
    const rows = [];
    sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      if (rowNumber > 120) return;
      const vals = row.values
        .slice(1)
        .map((v) => {
          if (v == null) return '';
          if (typeof v === 'object' && v.text) return String(v.text);
          if (typeof v === 'object' && v.result != null) return String(v.result);
          return String(v);
        })
        .filter((x) => x.trim());
      if (vals.length) {
        rows.push(vals.join(' | '));
        filas += 1;
      }
    });
    if (rows.length) parts.push(`## Hoja: ${sheet.name}\n${rows.join('\n')}`);
  });
  return { texto: truncate(parts.join('\n\n')), filas, hojas };
}

async function extractWordText(buffer) {
  let mammoth;
  try {
    mammoth = require('mammoth');
  } catch (_) {
    const err = new Error('Soporte Word no instalado (npm i mammoth). Mientras, sube PDF o texto.');
    err.status = 503;
    throw err;
  }
  const result = await mammoth.extractRawText({ buffer });
  return { texto: truncate(result.value || ''), filas: 0, hojas: 0 };
}

async function extractPdfText(buffer) {
  let pdfParse;
  try {
    pdfParse = require('pdf-parse');
  } catch (_) {
    const err = new Error('Soporte PDF no instalado (npm i pdf-parse). Mientras, sube texto o Word.');
    err.status = 503;
    throw err;
  }
  const result = await pdfParse(buffer);
  return { texto: truncate(result.text || ''), filas: 0, hojas: Number(result.numpages || 0) };
}

async function describeImage(buffer, mime, db) {
  try {
    const { getApiKey, getAngelModel } = require('./angel');
    const apiKey = await getApiKey(db);
    if (!apiKey) {
      return {
        texto: '[Imagen cargada al cerebro. No hay API key para describirla automáticamente. Agrega una nota de texto con el significado.]',
        filas: 0,
        hojas: 0
      };
    }
    const OpenAI = require('openai');
    const client = new OpenAI({ apiKey });
    const model = await getAngelModel(db);
    const b64 = buffer.toString('base64');
    const dataUrl = `data:${mime || 'image/jpeg'};base64,${b64}`;
    const resp = await client.chat.completions.create({
      model: /gpt-4o|gpt-4\.1|gpt-5/i.test(model) ? model : 'gpt-4o-mini',
      temperature: 0.2,
      max_tokens: 700,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'Describe esta imagen para el cerebro de un asistente empresarial chileno (ESERCOM). Extrae texto visible (OCR), tablas, reglas, nombres, números y el significado operativo. Responde en español, claro y concreto.'
            },
            { type: 'image_url', image_url: { url: dataUrl } }
          ]
        }
      ]
    });
    const texto = truncate(resp.choices?.[0]?.message?.content || '');
    return { texto: texto || '[Imagen sin descripción]', filas: 0, hojas: 0 };
  } catch (err) {
    return {
      texto: `[Imagen cargada. No se pudo analizar automáticamente: ${err.message}]`,
      filas: 0,
      hojas: 0
    };
  }
}

async function extractContent({ buf, mime, filename, tipo, db }) {
  if (tipo === 'excel') return extractExcelText(buf);
  if (tipo === 'word') return extractWordText(buf);
  if (tipo === 'pdf') return extractPdfText(buf);
  if (tipo === 'imagen') return describeImage(buf, mime, db);
  if (tipo === 'texto') {
    return { texto: truncate(buf.toString('utf8')), filas: 0, hojas: 0 };
  }
  const err = new Error('Tipo de archivo no soportado. Usa texto, imagen, Excel (.xlsx), Word (.docx) o PDF.');
  err.status = 400;
  throw err;
}

async function replaceChunks(db, docId, texto) {
  await db.prepare(`DELETE FROM ${CHUNKS} WHERE doc_id = ?`).run(docId);
  const chunks = chunkText(texto);
  for (let i = 0; i < chunks.length; i++) {
    await db.prepare(`
      INSERT INTO ${CHUNKS} (doc_id, idx_chunk, texto) VALUES (?, ?, ?)
    `).run(docId, i, chunks[i]);
  }
  return chunks.length;
}

function makeResumen(texto, tipo) {
  const line = String(texto || '').replace(/\s+/g, ' ').trim();
  const prefix = TYPE_META[tipo]?.label || 'Doc';
  return `${prefix}: ${line.slice(0, 180)}${line.length > 180 ? '…' : ''}`;
}

async function saveDoc(db, {
  nombre,
  archivo,
  tipo,
  mime,
  texto,
  filas = 0,
  hojas = 0,
  userId
}) {
  const resumen = makeResumen(texto, tipo);
  const info = await db.prepare(`
    INSERT INTO ${TABLE} (nombre, archivo, tipo, mime, texto, resumen, filas, hojas, creado_por)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    nombre,
    archivo || null,
    tipo,
    mime || null,
    texto,
    resumen,
    filas || 0,
    hojas || 0,
    userId || null
  );
  const id = info.lastInsertRowid;
  const chunks = await replaceChunks(db, id, texto);
  return { id, nombre, tipo, filas, hojas, chunks, resumen };
}

async function uploadAngelDoc(db, { dataUrl, filename, userId, titulo }) {
  await ensureAngelDocsSchema(db);
  const { buf, mime } = decodeDataUrl(dataUrl, 12);
  const name = safeName(filename || titulo || 'documento', 'documento.bin');
  const tipo = detectTipo(name, mime);
  if (tipo === 'otro') {
    const err = new Error('Formato no soportado. Usa .txt, .md, .xlsx, .docx, .pdf, .png, .jpg o .webp');
    err.status = 400;
    throw err;
  }
  if (tipo === 'word' && !/\.docx$/i.test(name)) {
    const err = new Error('Word antiguo (.doc) no soportado. Guarda como .docx');
    err.status = 400;
    throw err;
  }
  const extracted = await extractContent({ buf, mime, filename: name, tipo, db });
  if (!extracted.texto || extracted.texto.length < 8) {
    const err = new Error('No se pudo extraer contenido útil del archivo');
    err.status = 400;
    throw err;
  }
  const ext = path.extname(name) || (
    tipo === 'excel' ? '.xlsx'
      : tipo === 'word' ? '.docx'
        : tipo === 'pdf' ? '.pdf'
          : tipo === 'imagen' ? '.jpg'
            : '.txt'
  );
  const stored = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`;
  fs.writeFileSync(path.join(DIR, stored), buf);
  return saveDoc(db, {
    nombre: titulo ? safeName(titulo, name) : name,
    archivo: stored,
    tipo,
    mime,
    texto: extracted.texto,
    filas: extracted.filas,
    hojas: extracted.hojas,
    userId
  });
}

async function addAngelTextNote(db, { titulo, texto, userId }) {
  await ensureAngelDocsSchema(db);
  const body = truncate(String(texto || '').trim());
  if (body.length < 3) {
    const err = new Error('Escribe al menos unas líneas de texto');
    err.status = 400;
    throw err;
  }
  const nombre = safeName(titulo || `Nota ${new Date().toLocaleDateString('es-CL')}`, 'nota.txt');
  return saveDoc(db, {
    nombre,
    archivo: '',
    tipo: 'texto',
    mime: 'text/plain',
    texto: body,
    userId
  });
}

async function listAngelDocs(db) {
  await ensureAngelDocsSchema(db);
  const rows = await db.prepare(`
    SELECT id, nombre, archivo, tipo, mime, resumen, filas, hojas, fecha_creacion
    FROM ${TABLE}
    ORDER BY id DESC
    LIMIT 60
  `).all();
  return rows.map((r) => ({
    ...r,
    tipo: r.tipo || 'excel',
    tipo_label: TYPE_META[r.tipo || 'excel']?.label || 'Archivo',
    icon: TYPE_META[r.tipo || 'excel']?.icon || 'fa-file'
  }));
}

async function deleteAngelDoc(db, id) {
  await ensureAngelDocsSchema(db);
  const row = await db.prepare(`SELECT * FROM ${TABLE} WHERE id = ?`).get(Number(id));
  if (!row) {
    const err = new Error('Documento no encontrado');
    err.status = 404;
    throw err;
  }
  try {
    if (row.archivo) {
      const full = path.join(DIR, row.archivo);
      if (fs.existsSync(full)) fs.unlinkSync(full);
    }
  } catch (_) { /* ignore */ }
  await db.prepare(`DELETE FROM ${CHUNKS} WHERE doc_id = ?`).run(Number(id));
  await db.prepare(`DELETE FROM ${TABLE} WHERE id = ?`).run(Number(id));
  return { ok: true };
}

function tokenize(q) {
  return String(q || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .split(/[^a-z0-9áéíóúñü]+/i)
    .filter((t) => t.length > 2);
}

function scoreChunk(chunkText, tokens) {
  if (!tokens.length) return 0;
  const hay = String(chunkText || '').toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
  let score = 0;
  for (const t of tokens) {
    if (hay.includes(t)) score += 1 + Math.min(2, (hay.split(t).length - 1) * 0.15);
  }
  return score;
}

/**
 * Mente ligera: elige los trozos más relevantes a la pregunta.
 * Si no hay query, usa los documentos más recientes (resumen + inicio).
 */
async function getDocsPromptBlock(db, query = '') {
  try {
    await ensureAngelDocsSchema(db);
    const docs = await db.prepare(`
      SELECT id, nombre, tipo, resumen, texto, filas, hojas
      FROM ${TABLE}
      ORDER BY id DESC
      LIMIT 40
    `).all();
    if (!docs.length) return '';

    const index = docs.map((d, i) =>
      `${i + 1}. [${d.tipo || 'doc'}] ${d.nombre}${d.resumen ? ` — ${d.resumen}` : ''}`
    ).join('\n');

    const tokens = tokenize(query);
    let picked = [];

    if (tokens.length) {
      const chunks = await db.prepare(`
        SELECT c.texto, c.doc_id, d.nombre, d.tipo
        FROM ${CHUNKS} c
        JOIN ${TABLE} d ON d.id = c.doc_id
        ORDER BY c.id DESC
        LIMIT 400
      `).all();
      const ranked = chunks
        .map((c) => ({ ...c, score: scoreChunk(c.texto, tokens) }))
        .filter((c) => c.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, MAX_CHUNKS_IN_PROMPT);
      picked = ranked;
    }

    if (!picked.length) {
      picked = docs.slice(0, 4).map((d) => ({
        nombre: d.nombre,
        tipo: d.tipo,
        texto: String(d.texto || '').slice(0, 1400)
      }));
    }

    let body = '';
    for (const p of picked) {
      const block = `### ${p.nombre} (${p.tipo || 'doc'})\n${p.texto}`;
      if ((body + block).length > MAX_PROMPT_CHARS) break;
      body += (body ? '\n\n' : '') + block;
    }

    return `\n\nCEREBRO DE ANGEL (conocimiento cargado por admin — usa solo lo relevante; no inventes fuera de esto):\nÍNDICE:\n${index}\n\nFRAGMENTOS RELEVANTES:\n${body}`;
  } catch (_) {
    return '';
  }
}

module.exports = {
  ensureAngelDocsSchema,
  uploadAngelDoc,
  addAngelTextNote,
  listAngelDocs,
  deleteAngelDoc,
  getDocsPromptBlock,
  TYPE_META
};
