const express = require('express');
const path = require('path');
const fs = require('fs');
const { angelTrainRequired } = require('../middleware/angel-train');
const {
  getTrainingConfig,
  saveTrainingConfig,
  chatWithAngelTrain,
  clearTrainChat,
  getSecurityLog
} = require('../services/angel');
const { getApiConfigData, saveApiConfig, testApiConnection } = require('../services/angel-api-config');
const {
  scanUserMessage,
  getDefaultSecurityConfig
} = require('../services/angel-security');
const config = require('../config');

const router = express.Router();
router.use(angelTrainRequired);

router.get('/config', async (req, res) => {
  try {
    const data = await getTrainingConfig(req.db);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/config', async (req, res) => {
  try {
    const data = await saveTrainingConfig(req.db, req.body || {});
    res.json({ success: true, data, message: 'Entrenamiento y seguridad guardados. Angel IA ya los aplica.' });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

router.get('/api-config', async (req, res) => {
  try {
    const data = await getApiConfigData(req.db);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/api-config', async (req, res) => {
  try {
    const data = await saveApiConfig(req.db, req.body || {}, null);
    res.json({ success: true, data, message: 'Configuración API guardada' });
  } catch (err) {
    res.status(err.status || 400).json({ success: false, message: err.message });
  }
});

router.post('/api-config/probar', async (req, res) => {
  try {
    const data = await testApiConnection(req.db);
    res.json({ success: true, message: 'Conexión OpenAI correcta', data });
  } catch (err) {
    res.status(err.status || 400).json({ success: false, message: err.message });
  }
});

router.get('/seguridad/log', async (req, res) => {
  try {
    const data = await getSecurityLog(req.db, Number(req.query.limit) || 50);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/seguridad/escanear', async (req, res) => {
  try {
    const message = String(req.body?.message || '').trim();
    if (!message) {
      return res.status(400).json({ success: false, message: 'Escribe un mensaje para escanear' });
    }
    const cfg = await getTrainingConfig(req.db);
    const scan = scanUserMessage(message, { activa: cfg.seguridad?.activa !== false });
    res.json({ success: true, data: scan });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/seguridad/restaurar', async (req, res) => {
  try {
    const defaults = getDefaultSecurityConfig();
    const current = await getTrainingConfig(req.db);
    const data = await saveTrainingConfig(req.db, {
      instrucciones: current.instrucciones,
      ejemplos: current.ejemplos,
      seguridad: {
        activa: true,
        prompt_personalizado: '',
        ejemplos: defaults.ejemplos
      }
    });
    res.json({
      success: true,
      data,
      message: 'Reglas de seguridad base restauradas'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/conocimiento/restaurar', async (req, res) => {
  try {
    const { getDefaultTrainingPack } = require('../services/angel-knowledge');
    const defaults = getDefaultSecurityConfig();
    const pack = getDefaultTrainingPack();
    const data = await saveTrainingConfig(req.db, {
      instrucciones: pack.instrucciones,
      ejemplos: pack.ejemplos,
      seguridad: {
        activa: true,
        prompt_personalizado: '',
        ejemplos: defaults.ejemplos
      }
    });
    res.json({
      success: true,
      data,
      message: 'Conocimiento humano de Angel cargado (instrucciones + ejemplos + seguridad base)'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/conocimiento/docs', async (req, res) => {
  try {
    const { listAngelDocs } = require('../services/angel-docs');
    const data = await listAngelDocs(req.db);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/conocimiento/docs/upload', async (req, res) => {
  try {
    const { uploadAngelDoc } = require('../services/angel-docs');
    const data = await uploadAngelDoc(req.db, {
      dataUrl: req.body?.dataUrl,
      filename: req.body?.filename,
      titulo: req.body?.titulo,
      userId: req.trainAuth?.userId || null
    });
    res.status(201).json({
      success: true,
      data,
      message: `Cerebro actualizado (${data.tipo}). Angel ya puede usarlo.`
    });
  } catch (err) {
    res.status(err.status || 500).json({ success: false, message: err.message });
  }
});

router.post('/conocimiento/docs/texto', async (req, res) => {
  try {
    const { addAngelTextNote } = require('../services/angel-docs');
    const data = await addAngelTextNote(req.db, {
      titulo: req.body?.titulo,
      texto: req.body?.texto,
      userId: req.trainAuth?.userId || null
    });
    res.status(201).json({
      success: true,
      data,
      message: 'Nota de texto agregada al cerebro'
    });
  } catch (err) {
    res.status(err.status || 500).json({ success: false, message: err.message });
  }
});

router.post('/conocimiento/docs/:id/eliminar', async (req, res) => {
  try {
    const { deleteAngelDoc } = require('../services/angel-docs');
    await deleteAngelDoc(req.db, Number(req.params.id));
    res.json({ success: true });
  } catch (err) {
    res.status(err.status || 500).json({ success: false, message: err.message });
  }
});

router.get('/reportes/download/:file', async (req, res) => {
  const file = path.basename(req.params.file);
  const full = path.join(config.dataDir, 'reportes', file);
  if (!fs.existsSync(full)) {
    return res.status(404).json({ success: false, message: 'Archivo no encontrado' });
  }
  res.download(full, file);
});

router.get('/chat/historial', async (req, res) => {
  const rows = (await req.db.prepare(`
    SELECT id, rol, contenido, meta_json, fecha_creacion
    FROM angel_ia_train_mensajes
    ORDER BY id DESC LIMIT 40
  `).all()).reverse();
  const data = rows.map((m) => {
    let downloads = [];
    let security = null;
    try {
      const meta = m.meta_json ? JSON.parse(m.meta_json) : null;
      if (Array.isArray(meta?.downloads)) downloads = meta.downloads;
      if (meta?.security || meta?.blocked) security = meta.security || { blocked: true };
    } catch (_) { /* ignore */ }
    downloads = downloads.map((d) => ({
      ...d,
      download: String(d.download || '').replace(
        /^\/api\/angel\/reportes\/download\//,
        '/api/angel/train/reportes/download/'
      )
    }));
    return {
      id: m.id,
      rol: m.rol,
      contenido: m.contenido,
      fecha_creacion: m.fecha_creacion,
      downloads,
      security
    };
  });
  res.json({ success: true, data });
});

router.post('/chat', async (req, res) => {
  try {
    const message = String(req.body?.message || '').trim();
    if (!message) {
      return res.status(400).json({ success: false, message: 'Escribe un mensaje de prueba' });
    }
    const history = (await req.db.prepare(`
      SELECT rol, contenido FROM angel_ia_train_mensajes ORDER BY id DESC LIMIT 12
    `).all()).reverse();

    const result = await chatWithAngelTrain({
      db: req.db,
      company: req.trainAuth.company,
      message,
      history
    });
    res.json({ success: true, data: result });
  } catch (err) {
    const status = err.code === 'NO_API_KEY' ? 503 : 500;
    res.status(status).json({ success: false, message: err.message });
  }
});

router.delete('/chat', async (req, res) => {
  try {
    await clearTrainChat(req.db);
    res.json({ success: true, message: 'Historial de prueba borrado' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
