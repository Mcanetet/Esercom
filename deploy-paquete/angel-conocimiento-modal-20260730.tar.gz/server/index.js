const express = require('express');
const path = require('path');
const morgan = require('morgan');
const cors = require('cors');
const config = require('./config');
const { initAll } = require('./db/tenants');

const authRoutes = require('./routes/auth');
const catalogosRoutes = require('./routes/catalogos');
const solicitudesRoutes = require('./routes/solicitudes');
const modulesRoutes = require('./routes/modules');
const angelRoutes = require('./routes/angel');
const { startAngelScheduler } = require('./services/angel-scheduler');

async function boot() {
  await initAll();

  const app = express();

  app.use(morgan('dev'));
  app.use(cors());
  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true }));

  // Evita 401 cacheados por el navegador en APIs
  app.use('/api', (_req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.set('Pragma', 'no-cache');
    next();
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/catalogos', catalogosRoutes);
  app.use('/api/solicitudes', solicitudesRoutes);
  app.use('/api/modulos', modulesRoutes);
  // Train ANTES de /api/angel — si no, authRequired captura /train con JWT sin userId
  app.use('/api/angel/train', require('./routes/angel-train'));
  app.use('/api/angel', angelRoutes);

  app.get('/api/health', (_req, res) => {
    res.json({
      success: true,
      app: 'ESERCOM',
      version: '1.0.0',
      empresas: config.companies.map((c) => c.slug)
    });
  });

  app.use(express.static(config.publicDir));

  app.get('/', (_req, res) => {
    res.sendFile(path.join(config.publicDir, 'index.html'));
  });

  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    const file = path.join(config.publicDir, req.path);
    res.sendFile(file, (err) => {
      if (err) res.sendFile(path.join(config.publicDir, 'index.html'));
    });
  });

  app.use((err, _req, res, _next) => {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  });

  app.listen(config.port, () => {
    console.log(`ESERCOM corriendo en http://localhost:${config.port}`);
    console.log(`Empresas: ${config.companies.map((c) => c.name).join(', ')}`);
    startAngelScheduler();
  });
}

boot().catch((err) => {
  console.error('No se pudo iniciar ESERCOM:', err);
  process.exit(1);
});
