const OpenAI = require('openai');
const appConfig = require('../config');
const { decrypt } = require('./crypto');
const { getDashboardContext, getMovimientosSemana, scanPendientes, queryModule, listModules } = require('./angel-data');
const { buildExcelReport } = require('./angel-excel');
const { getDefaultTrainingPack, DEFAULT_INSTRUCCIONES, DEFAULT_EJEMPLOS } = require('./angel-knowledge');
const {
  getDefaultSecurityConfig,
  buildSecurityPrompt,
  scanUserMessage,
  logSecurityIncident,
  getSecurityLog,
  parseSegEjemplos,
  BLOCKED_REPLY
} = require('./angel-security');

async function getConfig(db) {
  return db.prepare('SELECT * FROM angel_ia_config WHERE id = 1').get();
}

function getEnvApiKey() {
  const key = appConfig.openai?.apiKey || '';
  return key ? key : null;
}

async function getAngelModel(db) {
  const cfg = await getConfig(db);
  return appConfig.openai?.model || cfg?.model || 'gpt-4o-mini';
}

async function isAngelActive(db) {
  if (getEnvApiKey()) return true;
  const cfg = await getConfig(db);
  return !!(cfg && cfg.activo && cfg.api_key_enc);
}

async function getAngelStatus(db) {
  const envKey = getEnvApiKey();
  const cfg = await getConfig(db);
  const model = await getAngelModel(db);
  const activo = await isAngelActive(db);
  return {
    activo,
    model,
    source: envKey ? 'env' : (cfg?.api_key_enc ? 'db' : null),
    hint: envKey ? 'OPENAI_API_KEY (servidor)' : (cfg?.api_key_hint || null),
    reporte_semanal: !!(cfg && cfg.reporte_semanal)
  };
}

async function getApiKey(db) {
  const envKey = getEnvApiKey();
  if (envKey) return envKey;

  const cfg = await getConfig(db);
  if (!cfg || !cfg.activo || !cfg.api_key_enc) return null;
  try {
    return decrypt(cfg.api_key_enc);
  } catch {
    return null;
  }
}

async function createAlert(db, alert, userId = null) {
  const uid = alert.usuario_id != null ? alert.usuario_id : userId;
  return db.prepare(`
    INSERT INTO angel_ia_alertas (tipo, severidad, titulo, mensaje, modulo, referencia, usuario_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    alert.tipo,
    alert.severidad || 'media',
    alert.titulo,
    alert.mensaje,
    alert.modulo || null,
    alert.referencia || null,
    uid
  );
}

async function syncAlerts(db) {
  const found = await scanPendientes(db);
  let created = 0;
  for (const a of found) {
    // Si ya existió (leída o no), no volver a alertar: evita que la campana
    // regenere la misma alerta tras marcarla como revisada.
    const exists = await db.prepare(`
      SELECT id FROM angel_ia_alertas
      WHERE referencia = ? AND tipo = ? AND usuario_id = ?
      LIMIT 1
    `).get(a.referencia || '', a.tipo, a.usuario_id);
    if (!exists) {
      await createAlert(db, a);
      created++;
    }
  }
  return { scanned: found.length, created };
}

async function generateCecoExcel(db, company, generadoPor) {
  const movimientos = await getMovimientosSemana(db);
  const ctx = await getDashboardContext(db, company);

  const result = await buildExcelReport({
    titulo: `AngelIA_${company.slug}_semanal`,
    sheets: [
      {
        name: 'Resumen CECO',
        rows: ctx.por_ceco
      },
      {
        name: 'Movimientos 7 dias',
        rows: movimientos
      },
      {
        name: 'Materiales top',
        rows: ctx.materiales_mas_solicitados
      },
      {
        name: 'Stock bajo',
        rows: ctx.stock_bajo
      }
    ]
  });

  const destinatarios = [...new Set(
    ctx.por_ceco.map((c) => c.jefe_email).filter(Boolean)
  )];

  const resumen = `Reporte semanal ${company.name}: ${ctx.resumen.solicitudes_materiales_activas} activas, ${movimientos.length} líneas de movimiento, ${ctx.resumen.materiales_stock_bajo} materiales con stock bajo. Destinatarios JP: ${destinatarios.join(', ') || 'sin emails'}.`;

  await db.prepare(`
    INSERT INTO angel_ia_reportes (tipo, titulo, archivo, destinatarios, resumen, generado_por)
    VALUES ('semanal_ceco', ?, ?, ?, ?, ?)
  `).run(
    `Reporte semanal CECO — ${company.name}`,
    result.relative,
    JSON.stringify(destinatarios),
    resumen,
    generadoPor || null
  );

  await createAlert(db, {
    tipo: 'reporte_semanal',
    severidad: 'baja',
    titulo: 'Reporte semanal Angel IA generado',
    mensaje: resumen,
    modulo: 'angel-ia',
    referencia: result.filename
  });

  return { ...result, resumen, destinatarios };
}

async function generateModuleExcel(db, company, generadoPor, modulo, titulo) {
  const pack = await queryModule(db, modulo, { limite: 200 });
  if (pack.error) return { ok: false, error: pack.error, disponibles: pack.disponibles };
  const sheetName = String(pack.label || modulo).slice(0, 31);
  const rows = pack.data || [];
  const result = await buildExcelReport({
    titulo: `AngelIA_${company.slug}_${modulo}`,
    sheets: [
      { name: sheetName, rows: rows.length ? rows : [{ info: 'Sin datos para este módulo' }] }
    ]
  });
  const resumen = `Informe ${pack.label}: ${rows.length} registros. ${titulo || ''}`.trim();
  await db.prepare(`
    INSERT INTO angel_ia_reportes (tipo, titulo, archivo, destinatarios, resumen, generado_por)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    `informe_${modulo}`,
    titulo || `Informe ${pack.label} — ${company.name}`,
    result.relative,
    '[]',
    resumen,
    generadoPor || null
  );
  return { ok: true, ...result, resumen, total: rows.length, modulo, label: pack.label };
}

const TOOLS = [
  {
    type: 'function',
    function: {
      name: 'obtener_resumen_empresa',
      description: 'Resumen operativo: pendientes de materiales, compras, SSGG, telecom, facturas, checklist flota, agenda camión e inventario',
      parameters: { type: 'object', properties: {} }
    }
  },
  {
    type: 'function',
    function: {
      name: 'listar_modulos',
      description: 'Lista los módulos de ESERCOM que Angel puede consultar o exportar a Excel',
      parameters: { type: 'object', properties: {} }
    }
  },
  {
    type: 'function',
    function: {
      name: 'consultar_modulo',
      description: 'Consulta datos reales de un módulo de la base ESERCOM (materiales, compras, checklist, agenda, facturas, etc.)',
      parameters: {
        type: 'object',
        properties: {
          modulo: {
            type: 'string',
            description: 'ID del módulo: materiales|compras|ssgg|telecom|facturas|checklist|agenda|contratos|usuarios|cecos|proveedores|inventario|recetas'
          },
          buscar: { type: 'string', description: 'Texto opcional para filtrar' },
          limite: { type: 'number', description: 'Máximo de filas (default 60, máx 200)' }
        },
        required: ['modulo']
      }
    }
  },
  {
    type: 'function',
    function: {
      name: 'generar_alertas',
      description: 'Escanea pendientes y genera/sincroniza alertas para usuarios',
      parameters: { type: 'object', properties: {} }
    }
  },
  {
    type: 'function',
    function: {
      name: 'generar_excel_semanal',
      description: 'Genera Excel semanal de movimientos por CECO y materiales (últimos 7 días)',
      parameters: { type: 'object', properties: {} }
    }
  },
  {
    type: 'function',
    function: {
      name: 'generar_informe_excel',
      description: 'Genera un Excel descargable con los datos actuales de un módulo (usa esto cuando pidan informe/reporte/Excel de flota, compras, agenda, etc.)',
      parameters: {
        type: 'object',
        properties: {
          modulo: {
            type: 'string',
            description: 'Módulo a exportar: materiales|compras|ssgg|telecom|facturas|checklist|agenda|contratos|usuarios|cecos|proveedores|inventario|recetas'
          },
          titulo: { type: 'string', description: 'Título del informe' },
          buscar: { type: 'string', description: 'Filtro opcional' }
        },
        required: ['modulo']
      }
    }
  },
  {
    type: 'function',
    function: {
      name: 'listar_alertas',
      description: 'Lista alertas no leídas recientes',
      parameters: {
        type: 'object',
        properties: {
          limite: { type: 'number' }
        }
      }
    }
  }
];

async function runTool(name, args, { db, company, userId }) {
  if (name === 'obtener_resumen_empresa') {
    return getDashboardContext(db, company);
  }
  if (name === 'listar_modulos') {
    return { modulos: listModules() };
  }
  if (name === 'consultar_modulo') {
    return queryModule(db, args?.modulo, { buscar: args?.buscar, limite: args?.limite });
  }
  if (name === 'generar_alertas') {
    return syncAlerts(db);
  }
  if (name === 'generar_excel_semanal') {
    const r = await generateCecoExcel(db, company, userId);
    return {
      ok: true,
      archivo: r.relative,
      download: `/api/angel/reportes/download/${pathBasename(r.filename)}`,
      resumen: r.resumen,
      destinatarios: r.destinatarios
    };
  }
  if (name === 'generar_informe_excel') {
    const r = await generateModuleExcel(db, company, userId, args?.modulo, args?.titulo);
    if (!r.ok) return r;
    return {
      ok: true,
      modulo: r.modulo,
      label: r.label,
      total: r.total,
      archivo: r.relative,
      download: `/api/angel/reportes/download/${pathBasename(r.filename)}`,
      resumen: r.resumen
    };
  }
  if (name === 'listar_alertas') {
    const limite = Number(args?.limite) || 15;
    return db.prepare(`
      SELECT id, tipo, severidad, titulo, mensaje, modulo, referencia, fecha_creacion
      FROM angel_ia_alertas WHERE leida = 0
      ORDER BY id DESC LIMIT ?
    `).all(limite);
  }
  return { error: 'Herramienta desconocida' };
}

function pathBasename(f) {
  return String(f).split(/[/\\]/).pop();
}

function parseEjemplos(raw) {
  try {
    const arr = JSON.parse(raw || '[]');
    return Array.isArray(arr) ? arr.filter((e) => e && e.pregunta && e.respuesta) : [];
  } catch {
    return [];
  }
}

async function getTrainingConfig(db) {
  const cfg = await getConfig(db);
  const defaults = getDefaultSecurityConfig();
  const pack = getDefaultTrainingPack();
  const segEjemplos = parseSegEjemplos(cfg?.ejemplos_seguridad);
  const instrucciones = String(cfg?.instrucciones_entrenamiento || '').trim() || pack.instrucciones;
  const ejemplosDb = parseEjemplos(cfg?.ejemplos_entrenamiento);
  return {
    instrucciones,
    ejemplos: ejemplosDb.length ? ejemplosDb : pack.ejemplos,
    usando_defaults: !String(cfg?.instrucciones_entrenamiento || '').trim(),
    modulos: pack.modulos,
    seguridad: {
      activa: cfg?.seguridad_activa == null ? true : !!cfg.seguridad_activa,
      prompt_base: defaults.prompt_base,
      prompt_personalizado: cfg?.prompt_seguridad || '',
      ejemplos: segEjemplos.length ? segEjemplos : defaults.ejemplos
    }
  };
}

async function saveTrainingConfig(db, body) {
  const instrucciones = String(body.instrucciones ?? body.instrucciones_entrenamiento ?? '').trim();
  let ejemplos = body.ejemplos ?? body.ejemplos_entrenamiento ?? [];
  if (typeof ejemplos === 'string') {
    try { ejemplos = JSON.parse(ejemplos); } catch { ejemplos = []; }
  }
  if (!Array.isArray(ejemplos)) ejemplos = [];
  const clean = ejemplos
    .map((e) => ({
      pregunta: String(e.pregunta || '').trim(),
      respuesta: String(e.respuesta || '').trim()
    }))
    .filter((e) => e.pregunta && e.respuesta)
    .slice(0, 40);

  const seg = body.seguridad || {};
  const promptSeg = String(seg.prompt_personalizado ?? body.prompt_seguridad ?? '').trim();
  const seguridadActiva = seg.activa === false || seg.activa === 0 ? 0 : 1;
  let segEjemplos = seg.ejemplos ?? body.ejemplos_seguridad ?? [];
  if (typeof segEjemplos === 'string') {
    try { segEjemplos = JSON.parse(segEjemplos); } catch { segEjemplos = []; }
  }
  const cleanSeg = parseSegEjemplos(JSON.stringify(Array.isArray(segEjemplos) ? segEjemplos : [])).slice(0, 30);

  const json = JSON.stringify(clean);
  const jsonSeg = JSON.stringify(cleanSeg);
  const driver = db.driver || 'sqlite';
  if (driver === 'mysql') {
    await db.prepare(`
      INSERT INTO angel_ia_config (
        id, instrucciones_entrenamiento, ejemplos_entrenamiento,
        prompt_seguridad, ejemplos_seguridad, seguridad_activa,
        model, activo, reporte_semanal, actualizado_en
      )
      VALUES (1, ?, ?, ?, ?, ?, 'gpt-4o-mini', 1, 1, NOW())
      ON DUPLICATE KEY UPDATE
        instrucciones_entrenamiento = VALUES(instrucciones_entrenamiento),
        ejemplos_entrenamiento = VALUES(ejemplos_entrenamiento),
        prompt_seguridad = VALUES(prompt_seguridad),
        ejemplos_seguridad = VALUES(ejemplos_seguridad),
        seguridad_activa = VALUES(seguridad_activa),
        actualizado_en = NOW()
    `).run(instrucciones, json, promptSeg, jsonSeg, seguridadActiva);
  } else {
    await db.prepare(`
      INSERT INTO angel_ia_config (
        id, instrucciones_entrenamiento, ejemplos_entrenamiento,
        prompt_seguridad, ejemplos_seguridad, seguridad_activa,
        model, activo, reporte_semanal, actualizado_en
      )
      VALUES (1, ?, ?, ?, ?, ?, 'gpt-4o-mini', 1, 1, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        instrucciones_entrenamiento = excluded.instrucciones_entrenamiento,
        ejemplos_entrenamiento = excluded.ejemplos_entrenamiento,
        prompt_seguridad = excluded.prompt_seguridad,
        ejemplos_seguridad = excluded.ejemplos_seguridad,
        seguridad_activa = excluded.seguridad_activa,
        actualizado_en = datetime('now')
    `).run(instrucciones, json, promptSeg, jsonSeg, seguridadActiva);
  }

  return {
    instrucciones,
    ejemplos: clean,
    seguridad: {
      activa: !!seguridadActiva,
      prompt_personalizado: promptSeg,
      ejemplos: cleanSeg
    }
  };
}

function buildAngelSystemPrompt({ company, user, ctx, training }) {
  const securityBlock = buildSecurityPrompt(training?.seguridad);
  const pack = getDefaultTrainingPack();
  const instrucciones = (training?.instrucciones || '').trim() || pack.instrucciones;
  const ejemplos = (training?.ejemplos && training.ejemplos.length) ? training.ejemplos : pack.ejemplos;

  let extra = `\n\nInstrucciones de entrenamiento (prioritarias):\n${instrucciones}`;
  if (ejemplos.length) {
    extra += `\n\nEjemplos de referencia:\n${ejemplos.map((e) => `P: ${e.pregunta}\nR: ${e.respuesta}`).join('\n\n')}`;
  }

  const mods = (ctx.modulos_disponibles || listModules())
    .map((m) => `${m.id}=${m.label}`)
    .join(', ');

  return `${securityBlock}

---

Eres Angel, compañero de trabajo digital de ESERCOM (${company.razonSocial} / ${company.name}).
Hablas como persona: natural, cercana, paciente y profesional en español chileno. No suenas a robot.
Usuario: ${user.nombreCompleto} (${user.rol}) — ${user.email}.

ORIENTACIÓN: Si preguntan qué se puede / no se puede, dónde hacer algo o cómo usar un módulo, explica con calma (página + pasos + límites). No finjas haber creado, aprobado ni guardado nada: esas acciones se hacen en las pantallas.

Contexto rápido (números reales): ${JSON.stringify(ctx.resumen)}.
Módulos consultables: ${mods}.

HERRAMIENTAS (úsalas siempre que necesites datos o archivos):
- obtener_resumen_empresa → panorama general
- listar_modulos → qué puedes consultar
- consultar_modulo → leer registros de un módulo (checklist, compras, agenda, etc.)
- generar_informe_excel → crear Excel descargable de un módulo (OBLIGATORIO si piden informe/reporte/Excel)
- generar_excel_semanal → Excel semanal CECO/materiales 7 días
- generar_alertas / listar_alertas → pendientes y avisos

Si piden “un informe” sin especificar, genera el semanal CECO y ofrece otros módulos.
Nunca inventes datos: consulta primero.
IMPORTANTE sobre Excel: cuando generes un informe, NO inventes ni pegues URLs (ni de esercom.cl ni de otros dominios). Di solo que el archivo está listo; la interfaz mostrará el botón Descargar.${extra}`;
}

function wantsReport(message) {
  return /informe|reporte|excel|exportar|descarg/i.test(String(message || ''));
}

function extractDownloads(toolResults) {
  const out = [];
  for (const t of toolResults || []) {
    const r = t?.result;
    if (!r || !r.ok || !r.download) continue;
    const file = pathBasename(r.archivo || r.download);
    out.push({
      titulo: r.label || r.resumen || (t.name === 'generar_excel_semanal' ? 'Excel semanal CECO' : 'Informe Excel'),
      resumen: r.resumen || null,
      download: r.download.startsWith('/') ? r.download : `/api/angel/reportes/download/${file}`,
      archivo: file,
      total: r.total != null ? r.total : null
    });
  }
  return out;
}

function sanitizeAngelReply(text, downloads) {
  let reply = String(text || '').trim();
  // Quitar links markdown / URLs inventadas hacia reportes
  reply = reply
    .replace(/\[[^\]]*\]\(\s*https?:\/\/[^)]*angel\/reportes[^)]*\)/gi, '')
    .replace(/https?:\/\/[^\s)]*angel\/reportes\/download\/[^\s)]+/gi, '')
    .replace(/https?:\/\/(?:www\.)?servicios?sercom\.cl[^\s)]*/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  if (downloads?.length) {
    const looksLikeLinkOnly = /descargarlo haciendo clic|siguiente botón|\[.*\]\(https?:\/\//i.test(reply)
      && reply.length < 320;
    if (!reply || looksLikeLinkOnly) {
      const names = downloads.map((d) => d.titulo).join(', ');
      reply = `Listo. Generé el Excel${names ? ` (${names})` : ''}. Usa el botón Descargar debajo de este mensaje.`;
    } else if (!/descargar|excel|informe|listo/i.test(reply)) {
      reply += '\n\nEl Excel está listo: usa el botón Descargar debajo.';
    }
  }
  return reply || 'Listo.';
}

async function handleSecurityScan({ db, company, user, message, training, persistTo, sandbox }) {
  const scan = scanUserMessage(message, { activa: training?.seguridad?.activa !== false });
  if (!scan.blocked) return null;

  const origen = sandbox ? 'entrenamiento' : 'produccion';
  await logSecurityIncident(db, {
    tipo: scan.tipo,
    severidad: scan.severidad,
    mensaje: message,
    usuario: user,
    bloqueado: true,
    detalle: { amenazas: scan.amenazas },
    origen
  });

  if (!sandbox && (scan.tipo === 'prompt_injection' || scan.severidad === 'alta')) {
    try {
      await createAlert(db, {
        tipo: 'seguridad_angel',
        severidad: scan.severidad || 'alta',
        titulo: 'Alerta: intento de manipulación en Angel IA',
        mensaje: `${user.nombreCompleto || user.email || 'Usuario'}: "${String(message).slice(0, 120)}…"`,
        modulo: 'angel-ia',
        referencia: scan.tipo,
        usuario_id: user.id || null
      });
    } catch (_) { /* no-op */ }
  }

  const reply = BLOCKED_REPLY;
  const meta = JSON.stringify({ security: scan, blocked: true });

  if (persistTo === 'train') {
    await db.prepare(`INSERT INTO angel_ia_train_mensajes (rol, contenido) VALUES ('user', ?)`).run(message);
    await db.prepare(`
      INSERT INTO angel_ia_train_mensajes (rol, contenido, meta_json) VALUES ('assistant', ?, ?)
    `).run(reply, meta);
  } else if (persistTo === 'prod' && user.id) {
    await db.prepare(`INSERT INTO angel_ia_mensajes (usuario_id, rol, contenido) VALUES (?, 'user', ?)`).run(user.id, message);
    await db.prepare(`
      INSERT INTO angel_ia_mensajes (usuario_id, rol, contenido, meta_json) VALUES (?, 'assistant', ?, ?)
    `).run(user.id, reply, meta);
  }

  return { reply, tools: [], security: scan, downloads: [] };
}

async function runAngelChat({ db, company, user, message, history, persistTo, sandbox }) {
  const training = await getTrainingConfig(db);
  const blocked = await handleSecurityScan({ db, company, user, message, training, persistTo, sandbox });
  if (blocked) return blocked;

  const apiKey = await getApiKey(db);
  if (!apiKey) {
    const err = new Error('Angel IA no está configurado. Define OPENAI_API_KEY en las variables del servidor.');
    err.code = 'NO_API_KEY';
    throw err;
  }

  const model = await getAngelModel(db);
  const client = new OpenAI({ apiKey });
  const ctx = await getDashboardContext(db, company);
  let docsBlock = '';
  try {
    const { getDocsPromptBlock } = require('./angel-docs');
    docsBlock = await getDocsPromptBlock(db);
  } catch (_) { /* ignore */ }
  const trainingWithDocs = docsBlock
    ? { ...training, instrucciones: `${training.instrucciones || ''}${docsBlock}` }
    : training;
  const system = buildAngelSystemPrompt({ company, user, ctx, training: trainingWithDocs });

  const messages = [
    { role: 'system', content: system },
    ...history.slice(-12).map((h) => ({ role: h.rol === 'assistant' ? 'assistant' : 'user', content: h.contenido })),
    { role: 'user', content: message }
  ];

  let response = await client.chat.completions.create({
    model,
    messages,
    tools: TOOLS,
    tool_choice: wantsReport(message) ? 'required' : 'auto',
    temperature: sandbox ? 0.55 : 0.45
  });

  let assistantMsg = response.choices[0].message;
  const toolResults = [];

  // Si forzamos informe genérico sin módulo, OpenAI a veces falla args; fallback semanal
  for (let i = 0; i < 5 && assistantMsg.tool_calls?.length; i++) {
    messages.push(assistantMsg);
    for (const call of assistantMsg.tool_calls) {
      let args = {};
      try { args = JSON.parse(call.function.arguments || '{}'); } catch (_) { /* */ }
      if (call.function.name === 'generar_informe_excel' && !args.modulo) {
        // Inferir módulo del mensaje o usar semanal
        const m = String(message || '').toLowerCase();
        if (/flota|checklist|patente/.test(m)) args.modulo = 'checklist';
        else if (/compra/.test(m)) args.modulo = 'compras';
        else if (/camion|pluma|agenda/.test(m)) args.modulo = 'agenda';
        else if (/factura/.test(m)) args.modulo = 'facturas';
        else if (/contrato/.test(m)) args.modulo = 'contratos';
        else if (/receta|tipo de obra|por actividad|paradero|insumo/.test(m)) args.modulo = 'recetas';
        else if (/stock|inventario|material/.test(m) && !/solicitud/.test(m)) args.modulo = 'inventario';
        else if (/ssgg|servicio general/.test(m)) args.modulo = 'ssgg';
        else if (/telecom/.test(m)) args.modulo = 'telecom';
        else if (/proveedor/.test(m)) args.modulo = 'proveedores';
        else if (/usuario|persona/.test(m)) args.modulo = 'usuarios';
        else if (/ceco/.test(m)) args.modulo = 'cecos';
        else {
          // Sin módulo claro → Excel semanal
          const result = await runTool('generar_excel_semanal', {}, { db, company, userId: user.id || 0 });
          toolResults.push({ name: 'generar_excel_semanal', result });
          messages.push({
            role: 'tool',
            tool_call_id: call.id,
            content: JSON.stringify(result)
          });
          continue;
        }
      }
      const result = await runTool(call.function.name, args, { db, company, userId: user.id || 0 });
      toolResults.push({ name: call.function.name, result });
      messages.push({
        role: 'tool',
        tool_call_id: call.id,
        content: JSON.stringify(result)
      });
    }
    response = await client.chat.completions.create({
      model,
      messages,
      tools: TOOLS,
      tool_choice: 'auto',
      temperature: sandbox ? 0.55 : 0.45
    });
    assistantMsg = response.choices[0].message;
  }

  // Si pidió informe y no usó tools, forzar semanal
  if (wantsReport(message) && !toolResults.length) {
    const result = await runTool('generar_excel_semanal', {}, { db, company, userId: user.id || 0 });
    toolResults.push({ name: 'generar_excel_semanal', result });
    messages.push({
      role: 'assistant',
      content: null,
      tool_calls: [{
        id: 'forced_semanal',
        type: 'function',
        function: { name: 'generar_excel_semanal', arguments: '{}' }
      }]
    });
    messages.push({
      role: 'tool',
      tool_call_id: 'forced_semanal',
      content: JSON.stringify(result)
    });
    response = await client.chat.completions.create({
      model,
      messages,
      temperature: 0.45
    });
    assistantMsg = response.choices[0].message;
  }

  const downloads = extractDownloads(toolResults);
  const rawReply = assistantMsg.content || '';
  const reply = sanitizeAngelReply(rawReply, downloads);
  const meta = JSON.stringify({
    tools: toolResults.map((t) => t.name),
    downloads
  });

  if (persistTo === 'train') {
    await db.prepare(`INSERT INTO angel_ia_train_mensajes (rol, contenido) VALUES ('user', ?)`).run(message);
    await db.prepare(`
      INSERT INTO angel_ia_train_mensajes (rol, contenido, meta_json) VALUES ('assistant', ?, ?)
    `).run(reply, meta);
  } else if (persistTo === 'prod' && user.id) {
    await db.prepare(`INSERT INTO angel_ia_mensajes (usuario_id, rol, contenido) VALUES (?, 'user', ?)`).run(user.id, message);
    await db.prepare(`
      INSERT INTO angel_ia_mensajes (usuario_id, rol, contenido, meta_json) VALUES (?, 'assistant', ?, ?)
    `).run(user.id, reply, meta);
  }

  return { reply, tools: toolResults, downloads };
}

async function clearTrainChat(db) {
  await db.prepare('DELETE FROM angel_ia_train_mensajes').run();
}

async function chatWithAngelTrain({ db, company, message, history = [] }) {
  const trainer = {
    id: 0,
    nombreCompleto: 'Entrenador Angel IA',
    rol: 'Entrenamiento',
    email: 'entrenamiento@esercom.internal'
  };
  const result = await runAngelChat({
    db,
    company,
    user: trainer,
    message,
    history,
    persistTo: 'train',
    sandbox: true
  });
  if (Array.isArray(result.downloads)) {
    result.downloads = result.downloads.map((d) => ({
      ...d,
      download: String(d.download || '').replace(
        /^\/api\/angel\/reportes\/download\//,
        '/api/angel/train/reportes/download/'
      )
    }));
  }
  return result;
}

async function chatWithAngel({ db, company, user, message, history = [] }) {
  return runAngelChat({
    db,
    company,
    user,
    message,
    history,
    persistTo: 'prod',
    sandbox: false
  });
}

module.exports = {
  getConfig,
  getApiKey,
  getEnvApiKey,
  getAngelModel,
  isAngelActive,
  getAngelStatus,
  getTrainingConfig,
  saveTrainingConfig,
  clearTrainChat,
  syncAlerts,
  createAlert,
  generateCecoExcel,
  chatWithAngel,
  chatWithAngelTrain,
  getDashboardContext,
  getSecurityLog
};
