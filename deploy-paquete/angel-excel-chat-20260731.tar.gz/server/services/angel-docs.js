/**
 * Documentos Excel de conocimiento para Angel IA (entrenamiento).
 */
const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const config = require('../config');

const TABLE = 'angel_ia_conocimiento_docs';
const DIR = path.join(config.dataDir, 'angel-conocimiento');
const MAX_TEXT = 14000;
const MAX_DOCS_IN_PROMPT = 4;

async function ensureAngelDocsSchema(db) {
  if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });
  if (db.driver === 'mysql') {
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLE} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(255) NOT NULL,
        archivo VARCHAR(512) NOT NULL,
        texto LONGTEXT NULL,
        filas INT NOT NULL DEFAULT 0,
        hojas INT NOT NULL DEFAULT 0,
        creado_por INT NULL,
        fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
  } else {
    await db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLE} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        archivo TEXT NOT NULL,
        texto TEXT,
        filas INTEGER NOT NULL DEFAULT 0,
        hojas INTEGER NOT NULL DEFAULT 0,
        creado_por INTEGER,
        fecha_creacion TEXT DEFAULT (datetime('now'))
      )
    `);
  }
}

function decodeDataUrl(dataUrl) {
  const m = String(dataUrl || '').match(/^data:([^;]+);base64,(.+)$/i);
  if (!m) {
    const err = new Error('Archivo inválido');
    err.status = 400;
    throw err;
  }
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 12 * 1024 * 1024) {
    const err = new Error('El Excel supera 12 MB');
    err.status = 400;
    throw err;
  }
  return buf;
}

async function extractExcelText(buffer) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer);
  const parts = [];
  let filas = 0;
  let hojas = 0;
  wb.eachSheet((sheet) => {
    hojas += 1;
    const rows = [];
    sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      if (rowNumber > 80) return;
      const vals = row.values
        .slice(1)
        .map((v) => {
          if (v == null) return '';
          if (typeof v === 'object' && v.text) return String(v.text);
          if (typeof v === 'object' && v.result != null) return String(v.result);
          return String(v);
        })
        .filter((x) => x.trim());
      if (vals.length) {
        rows.push(vals.join(' | '));
        filas += 1;
      }
    });
    if (rows.length) {
      parts.push(`## Hoja: ${sheet.name}\n${rows.join('\n')}`);
    }
  });
  let texto = parts.join('\n\n').trim();
  if (texto.length > MAX_TEXT) texto = texto.slice(0, MAX_TEXT) + '\n…[truncado]';
  return { texto, filas, hojas };
}

async function uploadAngelDoc(db, { dataUrl, filename, userId }) {
  await ensureAngelDocsSchema(db);
  const buf = decodeDataUrl(dataUrl);
  const name = String(filename || 'conocimiento.xlsx').replace(/[^\w.\- áéíóúñÁÉÍÓÚÑ]/g, '_').slice(0, 180);
  if (!/\.xlsx$/i.test(name)) {
    const err = new Error('Solo se aceptan archivos .xlsx');
    err.status = 400;
    throw err;
  }
  const { texto, filas, hojas } = await extractExcelText(buf);
  if (!texto) {
    const err = new Error('El Excel no tiene datos legibles');
    err.status = 400;
    throw err;
  }
  const stored = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.xlsx`;
  fs.writeFileSync(path.join(DIR, stored), buf);
  const info = await db.prepare(`
    INSERT INTO ${TABLE} (nombre, archivo, texto, filas, hojas, creado_por)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(name, stored, texto, filas, hojas, userId || null);
  return {
    id: info.lastInsertRowid,
    nombre: name,
    filas,
    hojas
  };
}

async function listAngelDocs(db) {
  await ensureAngelDocsSchema(db);
  return db.prepare(`
    SELECT id, nombre, archivo, filas, hojas, fecha_creacion
    FROM ${TABLE}
    ORDER BY id DESC
    LIMIT 40
  `).all();
}

async function deleteAngelDoc(db, id) {
  await ensureAngelDocsSchema(db);
  const row = await db.prepare(`SELECT * FROM ${TABLE} WHERE id = ?`).get(Number(id));
  if (!row) {
    const err = new Error('Documento no encontrado');
    err.status = 404;
    throw err;
  }
  try {
    const full = path.join(DIR, row.archivo);
    if (fs.existsSync(full)) fs.unlinkSync(full);
  } catch (_) { /* ignore */ }
  await db.prepare(`DELETE FROM ${TABLE} WHERE id = ?`).run(Number(id));
  return { ok: true };
}

async function getDocsPromptBlock(db) {
  try {
    await ensureAngelDocsSchema(db);
    const rows = await db.prepare(`
      SELECT nombre, texto, filas, hojas
      FROM ${TABLE}
      ORDER BY id DESC
      LIMIT ?
    `).all(MAX_DOCS_IN_PROMPT);
    if (!rows.length) return '';
    const body = rows.map((r, i) =>
      `### Documento ${i + 1}: ${r.nombre} (${r.hojas || 0} hojas, ${r.filas || 0} filas)\n${r.texto || ''}`
    ).join('\n\n');
    return `\n\nDOCUMENTOS DE CONOCIMIENTO (Excel cargados por admin — úsalos para responder reglas/datos de negocio; no inventes fuera de esto):\n${body}`;
  } catch (_) {
    return '';
  }
}

module.exports = {
  ensureAngelDocsSchema,
  uploadAngelDoc,
  listAngelDocs,
  deleteAngelDoc,
  getDocsPromptBlock
};
