/* Widget flotante Angel IA — icono abajo derecha (estilo WhatsApp), chat solo al pulsar */
(function () {
  const WIDGET_ID = 'angel-widget';

  function canUseAngel(user) {
    if (!user) return false;
    const canAccess = window.PagesCatalog?.canAccessPage || (() => true);
    return canAccess(user, 'angel-ia.html');
  }

  function isAngelPage() {
    return /\/angel-ia\.html$/i.test(window.location.pathname);
  }

  function isTrainPage() {
    return /\/(acceso-angel|angel-entrenamiento)\.html$/i.test(window.location.pathname);
  }

  function appendMsg(box, rol, text, downloads) {
    return window.AngelChatUI
      ? AngelChatUI.appendMsg(box, rol, text, downloads)
      : (() => {
        const el = document.createElement('div');
        el.className = `angel-msg ${rol === 'assistant' ? 'bot' : 'me'}`;
        el.innerHTML = '<div class="angel-bubble"></div>';
        el.querySelector('.angel-bubble').textContent = text;
        box.appendChild(el);
        box.scrollTop = box.scrollHeight;
        return el;
      })();
  }

  function createWidget() {
    if (document.getElementById(WIDGET_ID)) return document.getElementById(WIDGET_ID);

    const root = document.createElement('div');
    root.id = WIDGET_ID;
    root.className = 'angel-widget';
    root.innerHTML = `
      <div class="angel-widget-panel" id="angelWidgetPanel" hidden>
        <header class="angel-widget-head">
          <div class="angel-widget-head-info">
            <span class="angel-widget-avatar" aria-hidden="true"><i class="fas fa-robot"></i></span>
            <div>
              <strong>Angel IA</strong>
              <span id="angelWidgetStatus">Asistente ESERCOM</span>
            </div>
          </div>
          <div class="angel-widget-head-actions">
            <a href="/angel-ia.html" class="angel-widget-link" title="Abrir chat completo" onclick="event.stopPropagation()">
              <i class="fas fa-up-right-from-square"></i>
            </a>
            <button type="button" class="angel-widget-close" id="angelWidgetClose" aria-label="Minimizar chat">
              <i class="fas fa-chevron-down"></i>
            </button>
          </div>
        </header>
        <div class="angel-widget-body">
          <div class="angel-chat angel-widget-chat" id="angelWidgetChat"></div>
          <form class="angel-compose angel-widget-compose" id="angelWidgetForm">
            <input id="angelWidgetInput" placeholder="Escribe tu mensaje…" autocomplete="off">
            <button class="btn btn-primary" type="submit" aria-label="Enviar">
              <i class="fas fa-paper-plane"></i>
            </button>
          </form>
          <div class="angel-suggestions angel-widget-suggestions">
            <button type="button" data-q="¿Qué pendientes tengo?">Pendientes</button>
            <button type="button" data-q="Resume el estado de stock bajo">Stock</button>
            <button type="button" data-q="Genera el Excel semanal por CECO">Excel</button>
          </div>
        </div>
      </div>
      <button type="button" class="angel-widget-fab" id="angelWidgetFab"
        aria-label="Abrir Angel IA" aria-expanded="false" title="Angel IA">
        <span class="angel-widget-fab-icon angel-widget-fab-icon--open" aria-hidden="true">
          <i class="fas fa-robot"></i>
        </span>
        <span class="angel-widget-fab-icon angel-widget-fab-icon--close" aria-hidden="true">
          <i class="fas fa-times"></i>
        </span>
      </button>
    `;
    document.body.appendChild(root);
    return root;
  }

  window.initAngelWidget = function initAngelWidget(user) {
    if (!canUseAngel(user) || isAngelPage() || isTrainPage()) return;

    const root = createWidget();
    const panel = document.getElementById('angelWidgetPanel');
    const fab = document.getElementById('angelWidgetFab');
    const closeBtn = document.getElementById('angelWidgetClose');
    const chatBox = document.getElementById('angelWidgetChat');
    const form = document.getElementById('angelWidgetForm');
    const input = document.getElementById('angelWidgetInput');
    const statusEl = document.getElementById('angelWidgetStatus');

    let activo = false;
    let loaded = false;
    let sending = false;
    let isOpen = false;

    function setOpen(open) {
      isOpen = !!open;
      if (isOpen) {
        panel.removeAttribute('hidden');
        root.classList.add('is-open');
        fab.setAttribute('aria-expanded', 'true');
        fab.setAttribute('aria-label', 'Cerrar Angel IA');
        fab.setAttribute('title', 'Cerrar');
        if (!loaded) loadChat();
        setTimeout(() => input?.focus(), 150);
      } else {
        panel.setAttribute('hidden', '');
        root.classList.remove('is-open');
        fab.setAttribute('aria-expanded', 'false');
        fab.setAttribute('aria-label', 'Abrir Angel IA');
        fab.setAttribute('title', 'Angel IA');
      }
    }

    async function loadChat() {
      try {
        const [status, historial] = await Promise.all([
          Auth.api('/api/angel/status'),
          Auth.api('/api/angel/chat/historial')
        ]);
        activo = !!status.data?.activo;
        statusEl.textContent = activo
          ? `Activo · ${status.data.model || 'OpenAI'}`
          : 'Sin API key configurada';
        input.disabled = !activo;
        form.querySelector('button[type="submit"]').disabled = !activo;

        chatBox.innerHTML = '';
        const rows = historial.data || [];
        rows.forEach((m) => appendMsg(chatBox, m.rol, m.contenido, m.downloads));
        if (!rows.length) {
          appendMsg(chatBox, 'assistant', 'Hola, soy Angel IA. ¿En qué te ayudo?');
        }
        loaded = true;
      } catch (err) {
        statusEl.textContent = 'No disponible';
        chatBox.innerHTML = '';
        appendMsg(chatBox, 'assistant', err.message || 'No se pudo cargar Angel IA.');
        input.disabled = true;
        form.querySelector('button[type="submit"]').disabled = true;
        loaded = true;
      }
    }

    async function sendMessage(msg) {
      if (!msg || sending || !activo) return;
      sending = true;
      input.disabled = true;
      form.querySelector('button[type="submit"]').disabled = true;

      appendMsg(chatBox, 'user', msg);
      const thinking = appendMsg(chatBox, 'assistant', 'Pensando…');
      try {
        const r = await Auth.api('/api/angel/chat', {
          method: 'POST',
          body: JSON.stringify({ message: msg })
        });
        if (window.AngelChatUI) {
          AngelChatUI.setBubble(thinking, r.data.reply, r.data.downloads);
        } else {
          thinking.querySelector('.angel-bubble').textContent = r.data.reply;
        }
      } catch (err) {
        if (window.AngelChatUI) AngelChatUI.setBubble(thinking, err.message);
        else thinking.querySelector('.angel-bubble').textContent = err.message;
      } finally {
        sending = false;
        if (activo) {
          input.disabled = false;
          form.querySelector('button[type="submit"]').disabled = false;
          input.focus();
        }
      }
    }

    fab.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      setOpen(!isOpen);
    });

    closeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      setOpen(false);
    });

    panel.addEventListener('click', (e) => e.stopPropagation());

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = input.value.trim();
      if (!msg) return;
      input.value = '';
      sendMessage(msg);
    });

    root.querySelectorAll('[data-q]').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (!activo) return;
        input.value = btn.dataset.q;
        form.requestSubmit();
      });
    });

    document.addEventListener('click', (e) => {
      if (!isOpen) return;
      if (root.contains(e.target)) return;
      setOpen(false);
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && isOpen) setOpen(false);
    });

    // Siempre inicia cerrado — solo icono visible
    setOpen(false);
  };
})();
