/**
 * Helpers UI de chat Angel: bubbles + card de descarga autenticada.
 */
(function () {
  if (!document.getElementById('angel-dl-card-css')) {
    const s = document.createElement('style');
    s.id = 'angel-dl-card-css';
    s.textContent = `
.angel-dl-card{margin-top:.65rem;padding:.7rem .75rem;border-radius:12px;background:#f0fdf4;border:1px solid #86efac;display:flex;flex-wrap:wrap;align-items:center;gap:.55rem .75rem}
.angel-dl-card-body{flex:1 1 140px;min-width:0;display:flex;flex-direction:column;gap:.15rem}
.angel-dl-card-body strong{font-size:.86rem;color:#166534;display:flex;align-items:center;gap:.35rem}
.angel-dl-card-body small{font-size:.72rem;color:#64748b;word-break:break-all}
.angel-dl-card .angel-dl-btn{flex:0 0 auto}
.angel-msg.me .angel-dl-card{background:rgba(255,255,255,.18);border-color:rgba(255,255,255,.35)}
.angel-msg.me .angel-dl-card-body strong{color:#fff}
.angel-msg.me .angel-dl-card-body small{color:rgba(255,255,255,.75)}`;
    document.head.appendChild(s);
  }

  function esc(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function authToken() {
    return window.Auth?.getToken?.()
      || window.AngelTrainAuth?.getToken?.()
      || localStorage.getItem('auth_token')
      || localStorage.getItem('angel_train_token');
  }

  async function downloadAuth(url, name) {
    const token = authToken();
    const headers = {};
    if (token) {
      headers.Authorization = 'Bearer ' + token;
      headers['X-Angel-Train-Token'] = token;
    }
    const res = await fetch(url, { headers });
    if (!res.ok) throw new Error('No se pudo descargar el Excel');
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name || 'reporte_angel.xlsx';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  function appendDownloadCards(bubble, downloads) {
    if (!bubble || !Array.isArray(downloads) || !downloads.length) return;
    downloads.forEach((d) => {
      const card = document.createElement('div');
      card.className = 'angel-dl-card';
      const title = d.titulo || d.archivo || 'Informe Excel';
      const meta = [
        d.total != null ? `${d.total} filas` : null,
        d.archivo || null
      ].filter(Boolean).join(' · ');
      card.innerHTML = `
        <div class="angel-dl-card-body">
          <strong><i class="fas fa-file-excel"></i> ${esc(title)}</strong>
          ${meta ? `<small>${esc(meta)}</small>` : ''}
        </div>
        <button type="button" class="btn btn-primary btn-sm angel-dl-btn">
          <i class="fas fa-download"></i> Descargar
        </button>`;
      card.querySelector('.angel-dl-btn').addEventListener('click', async (e) => {
        e.preventDefault();
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
          await downloadAuth(d.download, d.archivo || 'reporte_angel.xlsx');
        } catch (err) {
          if (window.UI?.flash) UI.flash(err.message, true);
          else alert(err.message);
        } finally {
          btn.disabled = false;
        }
      });
      bubble.appendChild(card);
    });
  }

  function appendMsg(box, rol, text, downloads) {
    const el = document.createElement('div');
    el.className = `angel-msg ${rol === 'assistant' ? 'bot' : 'me'}`;
    el.innerHTML = '<div class="angel-bubble"></div>';
    const bubble = el.querySelector('.angel-bubble');
    bubble.textContent = text || '';
    if (rol === 'assistant') appendDownloadCards(bubble, downloads);
    box.appendChild(el);
    box.scrollTop = box.scrollHeight;
    return el;
  }

  function setBubble(el, text, downloads) {
    const bubble = el?.querySelector?.('.angel-bubble');
    if (!bubble) return;
    bubble.textContent = text || '';
    bubble.querySelectorAll('.angel-dl-card').forEach((n) => n.remove());
    appendDownloadCards(bubble, downloads);
  }

  window.AngelChatUI = { appendMsg, setBubble, downloadAuth, appendDownloadCards };
})();
